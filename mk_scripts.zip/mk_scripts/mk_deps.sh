#!/bin/bash

DEPS_PATH="$1"

deps_list=""

runInstall=false
if [[ ! -f ".deps_installed" ]]; then
	while IFS='' read -r line || [[ -n "$line" ]]; do
		#Read DEPS file line by line.
		checkLine=$(echo "$line" | sed ':a;N;$!ba;s/\n//g')
		realLine=$(echo "$line" | tr '\n' ' ')
		
		if [ -z "$checkLine" ]; then
			continue
		fi
		
		if [ $(dpkg-query -W -f='${Status}' "$checkLine" 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
			runInstall=true;
		fi;
		
		deps_list+="$realLine"
	done < "$DEPS_PATH"

	if [[ $runInstall == true ]]; then
		sudo apt-get --yes install $deps_list
	fi
	
	touch ".deps_installed"
fi
