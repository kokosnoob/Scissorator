#!/bin/bash

LIBS_PATH=$(readlink -f "$1")
LIBS_DIR=$(readlink -f "$2")
INC_DIR=$(readlink -f "$3")
DYNDIR=$(readlink -f "$4")
TOOLCHAIN="$5" #"gcc", "clang", or "windows" work.

if [[ $TOOLCHAIN == "clang" ]]; then
	TOOLCHAIN="gcc" # Clang/GCC are both UNIX platforms, so it's OK to build sublibraries with GCC.
fi



while IFS='' read -r line || [[ -n "$line" ]]; do
	#Read DEPS file line by line.
	strippedLine=$(echo "$line" | sed ':a;N;$!ba;s/\n//g') #Strip line of tabs/whitespace
	
	if [ ! -z "$strippedLine" ]; then
		# Create an array to access individual elements
		realLine=$(echo "$line" | tr '\n' ' ')
		lineArr=($realLine)
		
		# Mine data from the line.
		libName="${lineArr[0]}"
		libURL="${lineArr[1]}"
		libTag="${lineArr[2]}"
		
		# If the library doesn't already exist
		if [ ! -d "${LIBS_DIR}/${libName}" ]; then
			cd "$LIBS_DIR"
			
			bash "install_${libName}.sh" "${libURL}" "${libTag}" "${INC_DIR}" "${DYNDIR}" "${TOOLCHAIN}"
			
			cd - > /dev/null
		fi
	fi
done < "$LIBS_PATH"
